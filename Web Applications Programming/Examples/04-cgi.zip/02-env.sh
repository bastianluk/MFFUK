#!/bin/bash

printf "Content-type: text/plain\n\r\n\r"

env

echo '-----'

while read line; do
    echo $line;
done
