<h2>This is the first page</h2>

<p>
From here, you may go to the <a href="?page=second">second page</a>.
</p>
