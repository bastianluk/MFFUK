<h2>This is the second page</h2>

<p>
From here, you may return back to the <a href="?page=first">first page</a>.
</p>
