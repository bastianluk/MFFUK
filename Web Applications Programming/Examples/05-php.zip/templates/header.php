<!DOCTYPE HTML>
<html>
<head>
<title>PHP File Including Example</title>
</head>

<body>
<h1>PHP File Including Example</h1>
