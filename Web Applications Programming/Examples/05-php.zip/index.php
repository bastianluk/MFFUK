<?php

// Include the common header (HTML head, headline, and tag openings).
include("templates/header.php");


// Get the displayed page ...
if (!empty($_GET['page'])) {
    $page = $_GET['page'];
} else {
    $page = 'first';
}

// And display it.
$page = "templates/$page.php";
if (!is_readable($page)) {
    echo "Error: $page not found";
} else {
    include($page);        // WARNING: The $page value should be properly tested/filtered first !!!
}

// Append common footer (tail of the page and tag closings).
include("templates/footer.php");
