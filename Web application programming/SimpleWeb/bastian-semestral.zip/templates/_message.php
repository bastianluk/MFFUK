<div class="messageBlock">
    <h4>Message</h4>
    <p><?= $decodedMessage ?></p>
</div>