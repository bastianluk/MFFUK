<?php
  $db_config = array(
    'server'   => 'localhost',
    'login'    => 'bastianl',
    'password' => 'testing', // does not need to be submitted with the project
    'database' => 'stud_bastianl',
   );