<?php

return [
    'ids' => ['array of ids']
];