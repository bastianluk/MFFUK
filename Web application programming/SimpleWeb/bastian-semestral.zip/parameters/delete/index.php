<?php

return [
    'id' => 'int',
    'position' => 'int'
];
