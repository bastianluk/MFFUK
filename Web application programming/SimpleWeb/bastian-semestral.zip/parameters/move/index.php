<?php

return [
    'id' => 'int',
    'oldPosition' => 'int',
    'newPosition' => 'int'
];
