<?php

return [
    'name' => 'string',
    'amount' => 'int'
];
