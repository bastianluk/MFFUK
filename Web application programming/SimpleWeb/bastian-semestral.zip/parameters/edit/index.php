<?php

return [
    'id' => 'int',
    'amount' => 'int'
];