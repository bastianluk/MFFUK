DIY-unix
========

zde je pár zdrojáků, třeba to někomu pomůže :)

hlavní kusy algoritmu fungují, ale pousta přepínačů ne (to by ale už neměl být problém)

taky hodně používám vlastní zásobník (fce push/pop), není to uplně krásné a mnohdy je snadnější použít find (ale zas když už to jednou člověk napíše...)

feel free to fork :)
